L'output di progetto relativo a questa azione � il portale realizzato.

Non potendo caricare su DELFI il DUMP del portale (il peso � di 450Mb) si � pensato di allegare uno screenshot della cartella di installazione e il dump del DB sql di DRUPAL.

Questi file come evidenza dell'implementazione